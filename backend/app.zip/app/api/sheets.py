# backend/app/api/sheets.py

from fastapi import APIRouter
from app.services.sheets_service import get_sheet_values

router = APIRouter()

@router.get("/test-read", tags=["Sheets"])
async def test_read_sheet():
    """
    Test reading data from Google Sheets.
    """
    try:
        # Example: Read A1:E10 range from the Scouting tab
        data = await get_sheet_values("Scouting!A1:E10")
        return {"status": "success", "data": data}
    except Exception as e:
        return {"status": "error", "message": str(e)}
