# backend/app/api/validate.py

from fastapi import APIRouter
from app.services.data_validation_service import validate_event_completeness

router = APIRouter()

@router.get("/validate/event")
async def validate_event():
    result = validate_event_completeness("app/data/unified_event_2025arc.json")
    return result
