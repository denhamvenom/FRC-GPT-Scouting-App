# backend/app/api/schema.py

from fastapi import APIRouter
from app.services.sheets_service import get_sheet_values
from app.services.schema_service import map_headers_to_tags

router = APIRouter()

@router.get("/learn", tags=["Schema"])
async def learn_schema():
    """
    Read the scouting spreadsheet headers and map them to Reefscape tags using GPT.
    """
    try:
        # Fetch the first row (headers) from the Scouting tab
        sheet_data = await get_sheet_values("Scouting!A1:Z1")
        headers = sheet_data[0] if sheet_data else []

        if not headers:
            return {"status": "error", "message": "No headers found in sheet."}

        # Ask GPT to map them
        mapping = await map_headers_to_tags(headers)
        
        return {
            "status": "success",
            "headers": headers,
            "mapping": mapping
        }

    except Exception as e:
        return {"status": "error", "message": str(e)}
