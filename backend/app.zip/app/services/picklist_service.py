# backend/app/services/picklist_service.py

import json
from typing import List, Dict
from openai import OpenAI


def build_picklist_from_unified_data(
    unified_dataset_path: str,
    first_pick_priorities: List[str],
    second_pick_priorities: List[str],
    third_pick_priorities: List[str]
) -> List[Dict]:
    """
    Builds a ranked picklist based on strategic priorities and scouting data.

    Args:
        unified_dataset_path (str): Path to the unified event dataset JSON.
        first_pick_priorities (List[str]): Ranked traits for first pick.
        second_pick_priorities (List[str]): Ranked traits for second pick.
        third_pick_priorities (List[str]): Ranked traits for third pick.

    Returns:
        List[Dict]: Ranked list of teams with reasoning.
    """

    # Load scouting data
    with open(unified_dataset_path, "r", encoding="utf-8") as f:
        unified_data = json.load(f)

    teams_data = unified_data.get("teams", {})

    # Construct GPT prompt
    system_prompt = """
You are an expert FRC alliance strategy advisor.
You will help rank teams based on scouting data and specific strategic desires for 1st, 2nd, and 3rd picks.
Use the following priorities for each pick and the provided team data to recommend a pick order.

ONLY output JSON:
[
  {
    "team_number": 8044,
    "score": 95,
    "reasoning": "Excellent auto, top scorer, fast climber"
  },
  ...
]

Focus heavily on matching the FIRST PICK priorities for top selections.
The SECOND PICK should prioritize complementary defense or consistency.
The THIRD PICK can prioritize flexibility or backup roles.
"""

    user_prompt = {
        "first_pick_priorities": first_pick_priorities,
        "second_pick_priorities": second_pick_priorities,
        "third_pick_priorities": third_pick_priorities,
        "teams_data": teams_data
    }

    # Initialize OpenAI client
    client = OpenAI()

    response = client.chat.completions.create(
        model="gpt-4o",  # Use "gpt-4" or "gpt-4o" depending on your access
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": json.dumps(user_prompt)}
        ],
        temperature=0.2,
        max_tokens=2000
    )

    output_text = response.choices[0].message.content
    try:
        picklist = json.loads(output_text)
    except json.JSONDecodeError:
        raise ValueError("Failed to parse GPT output as JSON.")

    return picklist
