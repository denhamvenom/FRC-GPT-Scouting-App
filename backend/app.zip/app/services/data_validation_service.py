# backend/app/services/data_validation_service.py

import json
from typing import Dict, List


def load_unified_dataset(path: str) -> Dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def validate_event_completeness(unified_dataset_path: str) -> Dict:
    dataset = load_unified_dataset(unified_dataset_path)

    expected_matches = dataset.get("expected_matches", [])
    teams_data = dataset.get("teams", {})

    scouting_records = set()
    superscouted_teams = set()

    # Build scouted records
    for team_number, team_data in teams_data.items():
        for match in team_data.get("scouting_data", []):
            if "qual_number" in match:
                scouting_records.add((int(match["qual_number"]), int(team_number)))

        for superscout_entry in team_data.get("superscouting_data", []):
            team_num_raw = superscout_entry.get("team_number")
            if team_num_raw is None:
                continue
            try:
                team_num = int(team_num_raw)
                superscouted_teams.add(team_num)
            except ValueError:
                continue

    # Build expected sets
    expected_match_records = {(entry["match_number"], entry["team_number"]) for entry in expected_matches}
    expected_team_numbers = {entry["team_number"] for entry in expected_matches}

    missing_scouting = expected_match_records - scouting_records
    missing_superscouting = expected_team_numbers - superscouted_teams

    status = "complete" if not missing_scouting and not missing_superscouting else "partial"

    return {
        "missing_scouting": [{"match_number": m[0], "team_number": m[1]} for m in sorted(missing_scouting)],
        "missing_superscouting": [{"team_number": team} for team in sorted(missing_superscouting)],
        "status": status
    }
