# backend/app/services/learning_setup_service.py

import random
from typing import Optional, Dict, Any
from app.services.statbotics_client import get_team_epa
from app.services.tba_client import get_event_teams

async def start_learning_setup(year: int, manual_url: Optional[str], manual_file: Optional[Any]) -> Dict[str, Any]:
    """
    Pulls 2–3 sample teams and prepares manual info for GPT variable discovery.
    """
    # For now, use 2025arc as hardcoded sample event for pulling teams (can be dynamic later)
    sample_event_key = "2025arc"
    event_teams = await get_event_teams(sample_event_key)
    team_keys = [team["key"].replace("frc", "") for team in event_teams]

    # Randomly sample 3 teams
    sample_team_keys = random.sample(team_keys, 3)

    slimmed_team_data = []
    for team_key in sample_team_keys:
        team_epa = get_team_epa(int(team_key), year)
        if team_epa:
            slimmed_team_data.append(team_epa)

    # Manual input - for now, just acknowledge presence
    manual_info = {
        "manual_url": manual_url,
        "manual_file_received": manual_file is not None
    }

    return {
        "year": year,
        "manual_info": manual_info,
        "sample_teams": slimmed_team_data
    }
