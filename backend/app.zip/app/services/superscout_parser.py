# backend/app/services/superscout_parser.py

import os
import json
from typing import List, Dict, Any

# Determine project structure paths
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")

# Load the Superscouting schema mappings
SCHEMA_PATH = os.path.join(DATA_DIR, "schema_superscout_2025.json")
OFFSETS_PATH = os.path.join(DATA_DIR, "schema_superscout_offsets_2025.json")

with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
    FIELD_MAPPING = json.load(f)

with open(OFFSETS_PATH, "r", encoding="utf-8") as f:
    ROBOT_GROUPS = json.load(f)

def parse_superscout_row(row: List[str], headers: List[str]) -> List[Dict[str, Any]]:
    """
    Parses a single row from the SuperScouting sheet into three robot-specific scouting entries.
    
    Args:
        row (List[str]): The full list of cell values for the row.
        headers (List[str]): The full list of headers from A1:Z1.

    Returns:
        List[Dict[str, Any]]: Three structured robot scouting dictionaries.
    """

    robot_entries = []

    for robot_label in ["robot_1", "robot_2", "robot_3"]:
        robot_data = {}
        columns = ROBOT_GROUPS.get(robot_label, [])
        
        for header in columns:
            if header not in FIELD_MAPPING:
                continue  # Ignore unmapped fields
            
            mapped_field = FIELD_MAPPING.get(header, "ignore")
            if mapped_field == "ignore":
                continue  # Skip irrelevant fields

            try:
                index = headers.index(header)
                value = row[index] if index < len(row) else None
                robot_data[mapped_field] = value
            except ValueError:
                # Header not found — continue safely
                continue

        # Only add robot data if a valid team_number exists
        if robot_data.get("team_number"):
            robot_entries.append(robot_data)

    return robot_entries
