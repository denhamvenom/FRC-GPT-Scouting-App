# backend/app/services/unified_event_data_service.py

import os
import json
from typing import List, Dict, Any

from app.services.schema_loader import load_schemas
from app.services.scouting_parser import parse_scouting_row
from app.services.superscout_parser import parse_superscout_row
from app.services.tba_client import get_event_teams, get_event_matches, get_event_rankings
# from app.services.statbotics_client import get_all_active_teams
from app.services.sheets_service import get_sheet_values

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")

def sanitize_for_json(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: sanitize_for_json(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [sanitize_for_json(item) for item in obj]
    elif obj is None:
        return ""
    else:
        return obj

async def build_unified_dataset(event_key: str, year: int, scouting_tab: str = "Scouting", superscout_tab: str = "SuperScouting") -> str:
    print("\U0001F535 Loading schemas for", year)
    load_schemas(year)

    # 1. Parse Match Scouting Data
    print("\U0001F535 Fetching Match Scouting data...")
    scouting_raw = await get_sheet_values(f"{scouting_tab}!A1:ZZ")
    headers = scouting_raw[0] if scouting_raw else []
    scouting_rows = scouting_raw[1:] if scouting_raw else []

    scouting_parsed = []
    for row in scouting_rows:
        parsed = parse_scouting_row(row, headers)
        if parsed:
            scouting_parsed.append(parsed)

    # 2. Parse SuperScouting Data
    print("\U0001F535 Fetching SuperScouting data...")
    superscouting_raw = await get_sheet_values(f"{superscout_tab}!A1:ZZ")
    superscouting_headers = superscouting_raw[0] if superscouting_raw else []
    superscouting_rows = superscouting_raw[1:] if superscouting_raw else []

    superscouting_parsed = []
    for row in superscouting_rows:
        parsed = parse_superscout_row(row, superscouting_headers)
        superscouting_parsed.extend(parsed)

    # 3. Pull TBA Data
    print("\U0001F535 Fetching TBA Teams, Matches, Rankings...")
    event_teams = await get_event_teams(event_key)
    event_matches = await get_event_matches(event_key)
    event_rankings = await get_event_rankings(event_key)

    # 3.5 Build Expected Match List
    expected_matches = []

    for match in event_matches:
        if match.get("comp_level") == "qm":  # Only qualification matches
            match_number = match.get("match_number")
            alliances = match.get("alliances", {})

            for color in ["blue", "red"]:
                teams = alliances.get(color, {}).get("team_keys", [])
                for team_key in teams:
                    if team_key.startswith("frc"):
                        team_number = int(team_key[3:])
                        expected_matches.append({
                            "match_number": match_number,
                            "team_number": team_number
                        })

    # 4. Pull Statbotics Data
    print("\U0001F535 Fetching Statbotics EPA data...")
    # all_teams_stats = get_all_active_teams()
    statbotics_lookup = {team["team"]: team for team in all_teams_stats}

    # 5. Merge all data
    print("\U0001F7E2 Merging datasets...")
    unified_data = {}

    for team in event_teams:
        team_number = team.get("team_number")
        team_key = f"frc{team_number}"

        unified_data[team_number] = {
            "team_number": team_number,
            "nickname": team.get("nickname"),
            "scouting_data": [r for r in scouting_parsed if r.get("team_number") == str(team_number)],
            "superscouting_data": [r for r in superscouting_parsed if r.get("team_number") == str(team_number)],
            "tba_info": team,
            "statbotics_info": statbotics_lookup.get(team_number, {}),
            "ranking_info": next((r for r in event_rankings.get("rankings", []) if r.get("team_key") == team_key), {})
        }

    # 6. Save unified data locally
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR)

    output_path = os.path.join(DATA_DIR, f"unified_event_{event_key}.json")
    output_payload = {
        "expected_matches": expected_matches,
        "teams": sanitize_for_json(unified_data)
    }

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output_payload, f, indent=2)

    print("\u2705 Unified dataset saved to:", output_path)

    return output_path
