# backend/app/services/scouting_parser.py

import os
import json
from typing import List, Dict, Any
from app.services.schema_loader import get_match_mapping

def parse_scouting_row(row: List[str], headers: List[str]) -> Dict[str, Any]:
    """
    Parses a single row from the Match Scouting sheet.

    Args:
        row (List[str]): The full list of cell values for the row.
        headers (List[str]): The full list of headers from A1:Z1.

    Returns:
        Dict[str, Any]: Structured scouting dictionary
    """

    match_mapping = get_match_mapping()

    scouting_data = {}

    for header in headers:
        if header not in match_mapping:
            continue

        mapped_field = match_mapping.get(header, "ignore")
        if mapped_field == "ignore":
            continue

        try:
            index = headers.index(header)
            value = row[index] if index < len(row) else None
            scouting_data[mapped_field] = value
        except ValueError:
            continue

    # Only return entries that have a valid team_number
    if not scouting_data.get("team_number"):
        return {}

    return scouting_data
