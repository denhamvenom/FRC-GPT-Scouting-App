# backend/app/main.py

from fastapi import FastAPI
from dotenv import load_dotenv
import os
import openai

# Load environment variables and set OpenAI API key
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

from app.api import health
from fastapi.middleware.cors import CORSMiddleware
from app.api import sheets
from app.api import schema
from app.api import schema_save
from app.api import schema_superscout, schema_superscout_save
from app.api import test_unified
from app.api import validate
from app.api import picklist  
from app.api import setup
app = FastAPI(title="FRC Scouting Assistant", version="0.1.0")

# Allow frontend (localhost:5173) to call backend (localhost:8000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(health.router, prefix="/api/health")
app.include_router(sheets.router, prefix="/api/sheets")
app.include_router(schema.router, prefix="/api/schema")
app.include_router(schema_save.router, prefix="/api/schema")
app.include_router(schema_superscout.router, prefix="/api/schema/super")
app.include_router(schema_superscout_save.router, prefix="/api/schema/super")
app.include_router(test_unified.router)
app.include_router(validate.router, prefix="/api")
app.include_router(picklist.router, prefix="/api")  # ADD this too
app.include_router(setup.router)


@app.get("/")
async def root():
    return {"message": "Backend is running!"}
